const nnInputsCount = 13;
const nnOutputsCount = 4;
const nnLayersCount = 3;
const nnLayersSize = 30;
const playerSpeed = 2;
const playerRotateSpeed = 5;
const mutationRate = 0.1;
const generationSize = 50;
const maxFrames = 1000;
const mapSize = 30;

var startPoint = new Point(1, 1);
var finishPoint = new Point(29, 29);

class Point{
    constructor(x, y){
        this.x = x;
        this.y = y;
    }
    distance(other_point){
        if(!(other_point instanceof Point)) throw new Error("Given object is not valid point");
        return Math.sqrt(Math.pow(other_point.x - this.x, 2) + Math.pow(other_point.y - this.y, 2));
    }
    add(otherPoint) {
        return new Point(this.x + otherPoint.x, this.y + otherPoint.y);
    }
    multiply(scalar) {
        return new Point(this.x * scalar, this.y * scalar);
    }
    toNormalizedVector(){
        var length = this.distance(new Point(0, 0));
        return new Point(this.x / length, this.y / length);
    }
    toDegree(){
        var normVector = this.toNormalizedVector();
        var x = normVector.x;
        var y = normVector.y;
        if(x > 0 && y >= 0) return Math.asin(normVector.x)/ (Math.PI / 180);
        else if (x > 0 && y < 0) return (Math.asin(normVector.x)/ (Math.PI / 180)) + 90;
        else if (x < 0 && y < 0) return Math.abs((Math.asin(normVector.x)/ (Math.PI / 180))) + 180;
        else if (x < 0 && y >= 0) return (90-Math.abs((Math.asin(normVector.x)/ (Math.PI / 180)))) + 270;
        else if (x == 0 && y > 0) return 0;
        else if (x == 0 && y < 0) return 180;
        else if (x == 0 && y == 0) return 0;
    }
    length(){
        return this.distance(new Point(0, 0));
    }
    distanceToVector(A, V) {
        const AP = new Point(this.x - A.x, this.y - A.y);
        const crossProduct = Math.abs(AP.x * V.y - AP.y * V.x);
        const vectorLength = Math.sqrt(V.x * V.x + V.y * V.y);
        return crossProduct / vectorLength;
    }
}

class Direction{
    constructor(dir){
        this.direction = dir;
    }
    getVector(){
        return new Point(
            Math.sin(this.direction * (Math.PI / 180)),
            Math.cos(this.direction * (Math.PI / 180))
        );
    }
}

class Coin{
    constructor(position){
        this.position = position;
    }
}
class DeathPoint{
    constructor(position){
        this.position = position;
    }
}

class Game {
    constructor(playersCount) {
        this.players = [];
        this.neuralNets = [];
        this.generation = 0;
        this.bestScore = 0;
        this.coins = [];
        this.deathPoints = [];
        for (let i = 0; i < playersCount; i++) {
            this.players.push(new Player(startPoint));
            this.neuralNets.push(new NeuralNet(nnInputsCount, nnOutputsCount, nnLayersSize, nnLayersCount, RoundType.NO_ROUND, RoundType.TANH, RoundType.TANH));
        }
    }

    passOneGeneration() {
        for (let frame = 0; frame < maxFrames; frame++) {
            this.players.forEach((player, i) => {
                if (player.alive) {
                    let inputs = this.getInputsForPlayer(player);
                    let outputs = this.neuralNets[i].feedForward(inputs);
                    player.step(outputs[0], outputs[1], 100);
                    player.rotate(outputs[2]);
                    player.checkCollisions(this);
                }
            });
        }
        this.evolve();
    }

    getInputsForPlayer(player) {
        return [
            player.position.x / mapSize,
            player.position.y / mapSize,
        ];
    }

    evolve() {
        this.generation++;
        let scores = this.players.map(p => p.score);
        let bestIndex = scores.indexOf(Math.max(...scores));
        this.bestScore = scores[bestIndex];
        let bestNN = this.neuralNets[bestIndex];
        this.neuralNets = this.neuralNets.map(() => bestNN.clone().mutate(mutationRate));
        this.players = this.players.map(() => new Player(startPoint));
        console.log(`Generation ${this.generation} passed! Best score: ${this.bestScore}`);
    }
}

class Player {
    constructor(position, size) {
        this.position = position;
        this.direction = new Direction(0);
        this.score = 0;
    }
    
    step(forward, right, limit) {
        this.position = this.position.add(this.direction.getVector().multiply(forward * playerSpeed));
        this.position = this.position.add(new Direction(this.direction.direction + 90).getVector().multiply(right * playerSpeed));
        if (this.position.x < 0 || this.position.x > limit || this.position.y < 0 || this.position.y > limit) this.die();
    }
    
    rotate(rotation) {
        this.direction.direction += rotation * playerRotateSpeed;
    }
    
    checkCollisions(game) {
        if (this.collidesWithCoin(game)) this.score += 10;
        if (this.reachesFinish()) this.score += 100;
        if (this.collidesWithDeathPoint()) this.die();
    }
    
    collidesWithCoin(game) {
        game.coins.forEach(coin => {
            if(coin.position.distance(this.position) < playersSize){
                game.coins.remove(coin);
                return true;
            }
        });
        return false;
    }
    reachesFinish() {
        return this.position.distance(finishPoint) < playersSize;
    }
    collidesWithDeathPoint(game) {
        game.deathPoints.forEach(point => {
            if(point.position.distance(this.position) < playersSize){
                return true;
            }
        });
        return false;
    }
    
    die() {
        this.position = startPoint;
        this.score -= 50;
    }
}

var game = new Game(20);